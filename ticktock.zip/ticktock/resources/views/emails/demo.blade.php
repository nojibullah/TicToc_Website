<!DOCTYPE html>
<html>
<head>
    <title>Welcome Email</title>
</head>

<body>
<h2>Welcome to the site</h2>
<br/>
This is a email demo from 5balloons.info
</body>

</html>