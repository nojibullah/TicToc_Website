<script src="{{ asset('js/app.js') }}"></script>
<script type="text/javascript" src={{asset('js/jquery-1.8.3.min.js')}}></script>
<script type="text/javascript" src={{asset('js/jquery-ui.min.js')}}></script>
<script type="text/javascript" src={{asset('js/validation.js')}}></script>
<script type="text/javascript" src={{asset('js/responsee.js')}}></script>
<script type="text/javascript" src={{asset('js/plugins.min.js')}}></script>
<script type="text/javascript" src={{asset('owl-carousel/owl.carousel.js')}}></script>
<script type="text/javascript" src={{asset('js/jquery.easypiechart.min.js')}}></script>
<script type="text/javascript" src={{asset('js/template-scripts.js')}}></script>








