
<!-- Main Footer -->
<section class="section background-dark">
    <div class="line">
        <div class="margin2x">
            <div class="s-12 m-6 l-3 xl-5">
                <a  href="{{url('/shipping_return')}}"><h4 class="text-white text-strong">Free shipping & returns</h4></a>
            </div>
            <div class="s-12 m-6 l-3 xl-2">
                 <h4 class="text-white text-strong margin-m-top-30">Useful Links</h4>
            </div>
            <div class="s-12 m-6 l-3 xl-2">
                <h4 class="text-white text-strong margin-m-top-30">Term of Use</h4>
            </div>
            <div class="s-12 m-6 l-3 xl-3">
                <h4 class="text-white text-strong margin-m-top-30">Contact Us</h4>
            </div>
        </div>
    </div>
</section>