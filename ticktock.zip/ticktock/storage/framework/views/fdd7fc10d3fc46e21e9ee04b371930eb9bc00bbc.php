<!-- Social -->
<div class="background-primary padding text-center">
    <a href="<?php echo e(url('/recommendation')); ?>" class="s-12 m-6 l-3 center button border-radius background-green text-size-20 margin-top-10 text-white">Customer feedback</a>
</div>
<!-- Main Footer -->
<section class="section background-dark">
    <div class="line">
        <div class="margin2x">
            <div class="s-12 m-6 l-3 xl-5">
                <h4 class="text-white text-strong">Our Mission</h4>
            </div>
            <div class="s-12 m-6 l-3 xl-2">
                <h4 class="text-white text-strong margin-m-top-30">Useful Links</h4>
            </div>
            <div class="s-12 m-6 l-3 xl-2">
                <h4 class="text-white text-strong margin-m-top-30">Term of Use</h4>
            </div>
            <div class="s-12 m-6 l-3 xl-3">
                <h4 class="text-white text-strong margin-m-top-30">Contact Us</h4>
            </div>
        </div>
    </div>
</section><?php /**PATH D:\www\htdocs\ticktock123\resources\views/Layout/footer.blade.php ENDPATH**/ ?>