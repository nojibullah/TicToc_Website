<meta charset="UTF-8">
<title>Tick Tock</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css"
      integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">

<link rel="stylesheet" href=<?php echo e(asset('css/icons.css')); ?>>
<link rel="stylesheet" href=<?php echo e(asset('css/responsee.css')); ?>>
<link rel="stylesheet" href=<?php echo e(asset('owl-carousel/owl.carousel.css')); ?>>
<!-- CUSTOM STYLE -->
<link rel="stylesheet" href=<?php echo e(asset('css/template-style.css')); ?>>

<link href="https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,700,900&amp;subset=latin-ext" rel="stylesheet">
<script type="text/javascript" src=<?php echo e(asset('js/jquery-1.8.3.min.js')); ?>></script>
<style>
    @media  screen and (min-width: 992px) {
        .left-menu {
            margin-left: -145px;
        }
    }
</style><?php /**PATH D:\www\htdocs\ticktock\resources\views/Layout/head.blade.php ENDPATH**/ ?>