<script src="<?php echo e(asset('js/app.js')); ?>"></script>
<script type="text/javascript" src=<?php echo e(asset('js/jquery-1.8.3.min.js')); ?>></script>
<script type="text/javascript" src=<?php echo e(asset('js/jquery-ui.min.js')); ?>></script>
<script type="text/javascript" src=<?php echo e(asset('js/validation.js')); ?>></script>
<script type="text/javascript" src=<?php echo e(asset('js/responsee.js')); ?>></script>
<script type="text/javascript" src=<?php echo e(asset('js/plugins.min.js')); ?>></script>
<script type="text/javascript" src=<?php echo e(asset('owl-carousel/owl.carousel.js')); ?>></script>
<script type="text/javascript" src=<?php echo e(asset('js/jquery.easypiechart.min.js')); ?>></script>
<script type="text/javascript" src=<?php echo e(asset('js/template-scripts.js')); ?>></script>








<?php /**PATH F:\www\htdocs\ticktock\resources\views/Layout/foot.blade.php ENDPATH**/ ?>