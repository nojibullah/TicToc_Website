-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 22, 2019 at 04:41 AM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ticktock`
--

-- --------------------------------------------------------

--
-- Table structure for table `buy_history`
--

CREATE TABLE `buy_history` (
  `id` int(11) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `buy_watch_id` varchar(255) NOT NULL,
  `buy_watch_num` varchar(255) NOT NULL,
  `user_name` varchar(255) DEFAULT NULL,
  `user_email` varchar(255) DEFAULT NULL,
  `purchased_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `buy_history`
--

INSERT INTO `buy_history` (`id`, `user_id`, `buy_watch_id`, `buy_watch_num`, `user_name`, `user_email`, `purchased_time`) VALUES
(1, '1', '6', '3', 'Jackson', 'jackson@gmail.com', '2019-04-30 03:01:43'),
(2, '1', '21', '5', 'Jackson', 'jackson@gmail.com', '2019-04-30 03:13:48');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `user_id` varchar(255) NOT NULL,
  `watch_id` varchar(255) NOT NULL,
  `watch_num` int(11) NOT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`user_id`, `watch_id`, `watch_num`, `id`) VALUES
('7', '3', 1, 129),
('2', '2', 1, 132),
('2', '2', 1, 133),
('2', '2', 1, 134),
('2', '3', 1, 135);

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `password_resets`
--

INSERT INTO `password_resets` (`email`, `token`, `created_at`) VALUES
('jackson@gmail.com', '$2y$10$3hypatDmdKkYWL3emMX8f.xcJ6gOc5G4.Tx27js1qzjUiToixWuoG', '2019-04-22 01:37:29'),
('pc61300811@gmail.com', '$2y$10$PJvRxi.jv5cthkchkUXvQOjEVD9ms4SIqcqeoc0g/hIGb8aNcGJcG', '2019-04-22 22:24:25');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `brand` varchar(255) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `shape` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `re_price` int(11) DEFAULT NULL,
  `path` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `brand`, `gender`, `shape`, `type`, `description`, `quantity`, `price`, `re_price`, `path`) VALUES
(1, 'OMEGA', 'male', 'circle', 'metal12', 'This OMEGA watch is water-resistant 3 ATM guarantees that this timepiece will remain a forever-favorite.', 45, 40000, NULL, 'img/watch/man_circle_metal.jpg'),
(2, 'OMEGA', 'male', 'circle', 'automatic', 'This OMEGA watch is water-resistant 3 ATM guarantees that this timepiece will remain a forever-favorite.', 197, 10000, 6000, 'img/watch/man_circle_automatic.jpg'),
(3, 'OMEGA', 'male', 'circle', 'leather', 'This OMEGA watch is water-resistant 3 ATM guarantees that this timepiece will remain a forever-favorite.', 274, 40000, NULL, 'img/watch/man_circle_leather.jpg'),
(4, 'OMEGA', 'male', 'circle', 'rubber', 'This OMEGA watch is water-resistant 3 ATM guarantees that this timepiece will remain a forever-favorite.', 750, 10000, 6000, 'img/watch/man_circle_rubber.jpg'),
(5, 'OMEGA', 'male', 'circle', 'ceramic', 'This OMEGA watch is water-resistant 3 ATM guarantees that this timepiece will remain a forever-favorite.', 24, 40000, 2000, 'img/watch/man_circle_ceramic.jpg'),
(6, 'OMEGA', 'male', 'rect', 'metal', 'This OMEGA watch is water-resistant 3 ATM guarantees that this timepiece will remain a forever-favorite.', 17, 10000, 6000, 'img/watch/man_rect_metal.jpg'),
(7, 'OMEGA', 'male', 'rect', 'automatic', 'This OMEGA watch is water-resistant 3 ATM guarantees that this timepiece will remain a forever-favorite.', 5, 10000, 6000, 'img/watch/man_rect_automatic.jpg'),
(8, 'OMEGA', 'male', 'rect', 'leather', 'This OMEGA watch is water-resistant 3 ATM guarantees that this timepiece will remain a forever-favorite.', 20, 40000, 3000, 'img/watch/man_rect_leather.jpg'),
(9, 'OMEGA', 'male', 'rect', 'rubber', 'This OMEGA watch is water-resistant 3 ATM guarantees that this timepiece will remain a forever-favorite.', 15, 10000, 6000, 'img/watch/man_rect_rubber.jpg'),
(10, 'OMEGA', 'male', 'rect', 'ceramic', 'This OMEGA watch is water-resistant 3 ATM guarantees that this timepiece will remain a forever-favorite.', 39, 40000, NULL, 'img/watch/man_rect_ceramic.jpg'),
(11, 'ROLEX', 'male', 'circle', 'metal', 'This ROLEX watch is water-resistant 3 ATM guarantees that this timepiece will remain a forever-favorite.', 100, 40000, NULL, 'img/watch/r_male_circle_metal.jpg'),
(12, 'ROLEX', 'male', 'circle', 'automatic', 'This ROLEX watch is water-resistant 3 ATM guarantees that this timepiece will remain a forever-favorite.', 15, 10000, 6000, 'img/watch/r_male_circle_automatic.jpg'),
(13, 'ROLEX', 'male', 'circle', 'leather', 'This ROLEX watch is water-resistant 3 ATM guarantees that this timepiece will remain a forever-favorite.', 20, 40000, NULL, 'img/watch/r_male_circle_leather.jpg'),
(14, 'ROLEX', 'male', 'circle', 'rubber', 'This ROLEX watch is water-resistant 3 ATM guarantees that this timepiece will remain a forever-favorite.', 28, 10000, 6000, 'img/watch/r_male_circle_rubber.jpg'),
(15, 'ROLEX', 'male', 'circle', 'ceramic', 'This ROLEX watch is water-resistant 3 ATM guarantees that this timepiece will remain a forever-favorite.', 20, 40000, NULL, 'img/watch/r_male_circle_ceramic.jpg'),
(16, 'ROLEX', 'male', 'rect', 'metal', 'This ROLEX watch is water-resistant 3 ATM guarantees that this timepiece will remain a forever-favorite.', 45, 10000, 6000, 'img/watch/r_male_rect_metal.jpg'),
(17, 'ROLEX', 'male', 'rect', 'automatic', 'This ROLEX watch is water-resistant 3 ATM guarantees that this timepiece will remain a forever-favorite.', 60, 10000, 6000, 'img/watch/r_male_rect_automatic.jpg'),
(18, 'ROLEX', 'male', 'rect', 'leather', 'This ROLEX watch is water-resistant 3 ATM guarantees that this timepiece will remain a forever-favorite.', 50, 40000, NULL, 'img/watch/r_male_rect_leather.jpg'),
(19, 'ROLEX', 'male', 'rect', 'rubber', 'This ROLEX watch is water-resistant 3 ATM guarantees that this timepiece will remain a forever-favorite.', 83, 10000, 6000, 'img/watch/r_male_rect_rubber.jpg'),
(20, 'ROLEX', 'male', 'rect', 'ceramic', 'This ROLEX watch is water-resistant 3 ATM guarantees that this timepiece will remain a forever-favorite.', 90, 40000, NULL, 'img/watch/r_male_rect_ceramic.jpg'),
(21, 'OMEGA', 'female', 'circle', 'metal', 'OMEGA watch is water-resistant 3 ATM guarantees that this timepiece will remain a forever-favorite.', 115, 40000, NULL, 'img/watch/female_circle_metal.jpg'),
(22, 'OMEGA', 'female', 'circle', 'automatic', 'OMEGA watch is water-resistant 3 ATM guarantees that this timepiece will remain a forever-favorite.', 28, 40000, NULL, 'img/watch/female_circle_automatic.jpg'),
(23, 'OMEGA', 'female', 'circle', 'leather', 'OMEGA watch is water-resistant 3 ATM guarantees that this timepiece will remain a forever-favorite.', 68, 40000, NULL, 'img/watch/female_circle_leather.jpg'),
(24, 'OMEGA', 'female', 'circle', 'rubber', 'OMEGA watch is water-resistant 3 ATM guarantees that this timepiece will remain a forever-favorite.', 90, 40000, NULL, 'img/watch/female_circle_rubber.jpg'),
(25, 'OMEGA', 'female', 'circle', 'ceramic', 'OMEGA watch is water-resistant 3 ATM guarantees that this timepiece will remain a forever-favorite.', 100, 40000, NULL, 'img/watch/female_circle_ceramic.jpg'),
(26, 'OMEGA', 'female', 'rect', 'metal', 'This OMEGA watch is water-resistant 3 ATM guarantees that this timepiece will remain a forever-favorite.', 30, 40000, NULL, 'img/watch/female_rect_metal.jpg'),
(27, 'OMEGA', 'female', 'rect', 'automatic', 'This OMEGA watch is water-resistant 3 ATM guarantees that this timepiece will remain a forever-favorite.', 20, 40000, NULL, 'img/watch/female_rect_automatic.jpg'),
(28, 'OMEGA', 'female', 'rect', 'leather', 'This OMEGA watch is water-resistant 3 ATM guarantees that this timepiece will remain a forever-favorite.', 46, 40000, NULL, 'img/watch/female_rect_leather.jpg'),
(29, 'OMEGA', 'female', 'rect', 'rubber', 'This OMEGA watch is water-resistant 3 ATM guarantees that this timepiece will remain a forever-favorite.', 100, 40000, NULL, 'img/watch/female_rect_rubber.jpg'),
(30, 'OMEGA', 'female', 'rect', 'ceramic', 'This OMEGA watch is water-resistant 3 ATM guarantees that this timepiece will remain a forever-favorite.', 68, 40000, NULL, 'img/watch/female_rect_ceramic.jpg'),
(31, 'ROLEX', 'female', 'circle', 'metal', 'This ROLEX watch is water-resistant 3 ATM guarantees that this timepiece will remain a forever-favorite.', 80, 40000, NULL, 'img/watch/r_fe_cir_metal.jpg'),
(32, 'ROLEX', 'female', 'circle', 'automatic', 'This ROLEX watch is water-resistant 3 ATM guarantees that this timepiece will remain a forever-favorite.', 14, 10000, 6000, 'img/watch/r_fe_cir_auto.jpg'),
(33, 'ROLEX', 'female', 'circle', 'leather', 'This ROLEX watch is water-resistant 3 ATM guarantees that this timepiece will remain a forever-favorite.', 20, 40000, NULL, 'img/watch/r_fe_cir_leather.jpg'),
(34, 'ROLEX', 'female', 'circle', 'rubber', 'This ROLEX watch is water-resistant 3 ATM guarantees that this timepiece will remain a forever-favorite.', 35, 10000, 6000, 'img/watch/r_fe_cir_rubber.jpg'),
(35, 'ROLEX', 'female', 'circle', 'ceramic', 'This ROLEX watch is water-resistant 3 ATM guarantees that this timepiece will remain a forever-favorite.', 20, 40000, NULL, 'img/watch/r_fe_cir_ceramic.jpg'),
(36, 'ROLEX', 'female', 'rect', 'metal', 'This ROLEX watch is water-resistant 3 ATM guarantees that this timepiece will remain a forever-favorite.', 50, 10000, 6000, 'img/watch/r_fe_rect_metal.jpg'),
(37, 'ROLEX', 'female', 'rect', 'automatic', 'This ROLEX watch is water-resistant 3 ATM guarantees that this timepiece will remain a forever-favorite.', 20, 10000, 6000, 'img/watch/r_fe_rect_automatic.jpg'),
(38, 'ROLEX', 'female', 'rect', 'leather', 'This ROLEX watch is water-resistant 3 ATM guarantees that this timepiece will remain a forever-favorite.', 65, 40000, NULL, 'img/watch/r_fe_rect_leather.jpg'),
(39, 'ROLEX', 'female', 'rect', 'rubber', 'This ROLEX watch is water-resistant 3 ATM guarantees that this timepiece will remain a forever-favorite.', 15, 10000, 6000, 'img/watch/r_fe_rect_rubber.jpg'),
(40, 'ROLEX', 'female', 'rect', 'ceramic', 'This ROLEX watch is water-resistant 3 ATM guarantees that this timepiece will remain a forever-favorite.', 20, 40000, NULL, 'img/watch/r_fe_rect_ceramic.jpg'),
(41, 'ROLEX---', 'male', 'rect', 'ceramic', 'This ROLEX watch is water-resistant 3 ATM guarantees that this timepiece will remain a forever-favorite.', 30, 1000, NULL, 'img/watch/watch_metal.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `recommendation`
--

CREATE TABLE `recommendation` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `brand` varchar(255) DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `quality` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL,
  `come` varchar(255) NOT NULL,
  `service` varchar(255) NOT NULL,
  `content` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `recommendation`
--

INSERT INTO `recommendation` (`id`, `name`, `email`, `brand`, `type`, `quality`, `credit`, `come`, `service`, `content`) VALUES
(1, 'piaocheng', 'pc61300811@gmail.com', 'LOREX is very good', 'Automatic is very good', 'Good quality', '100% creadit', 'I will come here again', 'Top service', 'There are good watches inclusing rubber circle watch...'),
(2, 'piaocheng', 'pc61300811@gmail.com', 'LOREX is very good', 'Automatic is very good', 'Good quality', '100% creadit', 'I will come here again', 'Top service', 'GOOD!!!');

-- --------------------------------------------------------

--
-- Table structure for table `repairing`
--

CREATE TABLE `repairing` (
  `id` int(11) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `brand` varchar(255) NOT NULL,
  `back_number` varchar(255) DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `message` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `progress` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `price` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `repairing`
--

INSERT INTO `repairing` (`id`, `phone`, `brand`, `back_number`, `type`, `message`, `name`, `email`, `progress`, `description`, `price`) VALUES
(1, '1861726161', 'OMEGA', '3231', 'metal', 'Now my watch is not working well...', 'Jackson', 'jackson@gmail.com', 'Arrived...', 'We will repair your watch in a few days.', '1500'),
(5, '04320432043', 'TOMMY', 'MD2392', 'Leather', 'Broken screen', 'nilz', 'nilz123@gmail.com', 'Your watch has arrived', 'We are inspecting the damage, looks like a broken winder', '£950');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Jackson', 'jackson@gmail.com', NULL, '$2y$10$btTcnWdWnbQk3RnFEwDQl.E1Opy5twybOGbzh352WLtvtO6hdjWJu', NULL, '2019-04-20 19:35:22', '2019-04-20 19:35:22'),
(2, 'piaocheng', 'pc61300811@gmail.com', NULL, '$2y$10$MVu6LoJSEYS1RBQG2nCop.FhsCB1EPafJ6ao5kbzP.L2y.59BZRZK', 'Qvm8S7JQ9yFmcOwKcSgWEcsOZi9xNjTIkPVN6YTTYeIzDSOM0zG3lY5jmLK9', '2019-04-20 19:40:47', '2019-04-20 19:40:47'),
(3, 'N', 'nilz@gmail.com', NULL, '$2y$10$DxCrFFHnuEiO9rr7a5TqJexAtwPd91LMLfNVv.Jdnj/ItG7M1KONa', NULL, '2019-04-23 04:57:39', '2019-04-23 04:57:39'),
(4, 'JInD', 'JinD@gmail.com', NULL, '$2y$10$L1LdJ/aaGOwXrgayOhzXie67lkvA0wzNHXfrps/sZ9lwZkSaidEWS', NULL, '2019-04-23 21:53:05', '2019-04-23 21:53:05'),
(5, 'JInD', 'JinDD@gmail.com', NULL, '$2y$10$MZEjEiyuzpRt2nklGG0Vv.u3jNnGDm9s.U5JDvwuLFcXR951FIxOS', NULL, '2019-04-23 21:54:59', '2019-04-23 21:54:59'),
(6, 'piaocheng', 'JinD123@gmail.com', NULL, '$2y$10$tdspfMw9Oz/dipjrsYwxAOXCwWDRAbXre/lnK3movKT9JX8PjT.zC', NULL, '2019-04-23 23:12:41', '2019-04-23 23:12:41'),
(7, 'nilz', 'nilz123@gmail.com', NULL, '$2y$10$y2rK7c0DrAZBdWfxR62PEuEdBJJnsCKoFAbyG2W5C5IL2Ft8FW2o6', NULL, '2019-04-25 12:39:21', '2019-04-25 12:39:21'),
(8, 'Tomhouser', 'tolrenfrank1014@gmail.com', NULL, '$2y$10$LtOrqogFu59NOCFckxIRleCJJaH3ag8JmXVin2INNviN.X/ZdStq2', NULL, '2019-04-27 01:12:37', '2019-04-27 01:12:37');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `buy_history`
--
ALTER TABLE `buy_history`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `recommendation`
--
ALTER TABLE `recommendation`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `repairing`
--
ALTER TABLE `repairing`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `buy_history`
--
ALTER TABLE `buy_history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=136;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT for table `repairing`
--
ALTER TABLE `repairing`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
